// Banco de pruebas real del navegador, sin dependencias adicionales.
import {pngBlob,renderWheel,defaultOptions,bodyGlyphs} from '/wheel.js';
const frame=document.querySelector('#app'),checks=document.querySelector('#checks');let passed=0,failed=0;
function assert(value,message){if(!value)throw Error(message);}
async function until(fn){const start=performance.now();while(!fn()){if(performance.now()-start>12000)throw Error('Tiempo agotado esperando la interfaz.');await new Promise(r=>setTimeout(r,30));}}
async function check(name,fn){try{await fn();passed++;const li=document.createElement('li');li.className='pass';li.textContent='OK · '+name;checks.append(li);}catch(e){failed++;const li=document.createElement('li');li.className='fail';li.textContent='FALLÓ · '+name+': '+e.message;checks.append(li);}}
await until(()=>frame.contentDocument?.querySelector('#calculate')&&!frame.contentDocument.querySelector('#calculate').disabled);
const doc=frame.contentDocument,get=id=>doc.getElementById(id);
const change=(id,value)=>{get(id).value=value;get(id).dispatchEvent(new Event('change',{bubbles:true}));};
const fill=(id,value)=>{get(id).value=value;get(id).dispatchEvent(new Event('input',{bubbles:true}));};
const svg=()=>get('wheel').querySelector('svg');
const positions=()=>[...svg().querySelectorAll('[data-planet]')].map(p=>[p.dataset.planet,p.dataset.longitude]);
await check('Tabla tradicional completa disponible sin calcular carta',()=>{assert(get('traditional-table').tBodies[0].rows.length===12,'Faltan signos');assert(get('results').hidden,'Hay carta sin cálculo');});
get('sample').click();get('chart-form').requestSubmit();
await until(()=>svg()&&!get('results').hidden);
let original=JSON.stringify(positions());
await check('SVG válido, accesible, 360 marcas y nueve cuerpos',()=>{assert(!new DOMParser().parseFromString(svg().outerHTML,'image/svg+xml').querySelector('parsererror'),'XML inválido');assert(svg().querySelector('desc'),'Falta descripción');assert(svg().querySelectorAll('[data-degree]').length===360,'Marcas');assert(positions().length===9,'Cuerpos');});
for(const system of ['alcabitius','regiomontanus','placidus','whole_sign'])await check('Selector, tabla, rueda y exportación coinciden: '+system,async()=>{
 change('house-system',system);await until(()=>!get('results').hidden&&svg()?.dataset.houseSystem===system);
 assert(JSON.stringify(positions())===original,'Cambiaron planetas');
 const cusps=[...svg().querySelectorAll('[data-cusp]')],rows=[...get('cusps').rows];assert(cusps.length===12&&rows.length===12,'Doce cúspides');
 for(let i=0;i<12;i++)assert(Math.abs(Number(cusps[i].dataset.longitude)-parseFloat(rows[i].cells[4].textContent))<.000001,'Tabla/rueda distintos');
 const serialized=new XMLSerializer().serializeToString(svg()),parsed=new DOMParser().parseFromString(serialized,'image/svg+xml');assert(parsed.documentElement.getAttribute('data-house-system')===system,'SVG pierde sistema');
 if(system==='whole_sign'){assert(cusps.every(c=>Number(c.dataset.longitude)%30===0),'No empiezan a cero');assert(Number(svg().querySelector('[data-axis="ASC"]').dataset.longitude)!==Number(cusps[0].dataset.longitude),'ASC confundido con I');}
});
await check('Semisumas precargadas, tabla y rueda coinciden, personalización y restablecimiento',()=>{
 const inputs=[...get('orb-inputs').querySelectorAll('input')];assert(inputs.length===7&&inputs.every(i=>i.value!==''),'No hay siete orbes');
 const count=()=>[...get('aspect-list').rows].filter(r=>r.cells[6].textContent==='Dentro de orbe').length;
 assert(get('aspect-list').rows.length===105,'Faltan aspectos fuera de orbe');assert(count()===svg().querySelectorAll('[data-aspect]').length,'Tabla y rueda difieren');const initial=count();
 inputs.forEach(i=>{i.value='0';i.dispatchEvent(new Event('input',{bubbles:true}));});assert(count()===0,'No actualiza');
 get('reset-orbs').click();assert(count()===initial&&inputs[0].value==='15','No restablece');
 get('show-aspects').click();assert(!svg().querySelector('[data-aspect]'),'No oculta');get('show-aspects').click();assert(svg().querySelectorAll('[data-aspect]').length===initial,'No recupera');
});
await check('Orbe inválido impide una exportación obsoleta y se recupera al corregir',()=>{const input=get('orb-inputs').querySelector('input');input.value='-1';input.dispatchEvent(new Event('input',{bubbles:true}));assert(!svg(),'Conserva rueda obsoleta');assert(get('download-svg').disabled&&get('download-png').disabled,'Permite descargar');input.value='6';input.dispatchEvent(new Event('input',{bubbles:true}));assert(svg()&&!get('download-svg').disabled,'No recupera rueda');});
await check('Ocultar grados y cúspides conserva los ángulos reales',()=>{get('show-degrees').click();assert(!svg().querySelector('[data-label="10°22′"]'),'No oculta grado');get('show-degrees').click();get('show-cusps').click();assert(!svg().querySelector('[data-cusp]'),'No oculta cúspides');assert(svg().querySelectorAll('[data-axis]').length===4,'Ocultó ángulos');get('show-cusps').click();});
for(const mobile of [false,true])await check('Sin recortes ni desbordamiento: '+(mobile?'390 px':'1366 px'),async()=>{
 frame.classList.toggle('mobile',mobile);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
 assert(doc.documentElement.scrollWidth<=frame.clientWidth,'Desbordamiento de página');const rect=svg().getBoundingClientRect();assert(Math.abs(rect.width-rect.height)<1,'No es cuadrada');
 const inverse=svg().getScreenCTM().inverse();
 for(const path of svg().querySelectorAll('path')){const b=path.getBBox(),matrix=inverse.multiply(path.getScreenCTM());for(const [x,y] of [[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height]]){const p=new DOMPoint(x,y).matrixTransform(matrix);assert(p.x>=svg().viewBox.baseVal.x&&p.y>=svg().viewBox.baseVal.y&&p.x<=svg().viewBox.baseVal.x+svg().viewBox.baseVal.width&&p.y<=svg().viewBox.baseVal.y+svg().viewBox.baseVal.height,'Glifo fuera del SVG');}}
 if(mobile){change('wheel-zoom','300');assert(get('wheel').clientWidth>get('wheel').parentElement.clientWidth*2.9,'Zoom no funciona');assert(doc.documentElement.scrollWidth<=frame.clientWidth,'Zoom desborda página');change('wheel-zoom','100');}
});
await check('Dignidades, referencia y anillo consultan los mismos datos; control, toque y puntuación',async()=>{
 const {terms,referenceRows,evaluateDignities}=await import('/dignities.js');
 assert(get('dignities-cards').children.length===7,'No hay siete planetas');
 for(const card of get('dignities-cards').children){const name=card.dataset.dignityPlanet,longitude=Number(svg().querySelector(`[data-planet="${name}"]`).dataset.longitude),r=evaluateDignities(name,longitude,'diurna');const rows=card.querySelectorAll('tr');for(let i=0;i<7;i++){assert(rows[i].cells[0].textContent===r.testimonies[i].dignity,'Nombre distinto');assert(rows[i].cells[1].textContent===(r.testimonies[i].found?'Sí':'No'),'Cálculo y tabla de dignidades difieren');}}assert(get('traditional-table').tBodies[0].rows.length===12,'Faltan signos');
 const ref=referenceRows(),groups=[...svg().querySelectorAll('[data-term]')];assert(groups.length===60,'Faltan términos');
 for(const group of groups){const [i,j]=group.dataset.term.split('-').map(Number),term=ref[i].terms[j];assert(Number(group.dataset.start)===i*30+term.start&&Number(group.dataset.end)===i*30+term.end&&group.dataset.ruler===term.ruler,'Límite/regente distinto');assert(get('traditional-table').tBodies[0].rows[i].cells[8].textContent.includes(`${term.ruler} [${term.start}°, ${term.end}°)`),'Referencia distinta');}
 groups[0].dispatchEvent(new MouseEvent('click',{bubbles:true}));assert(get('term-info').textContent.includes('Aries: [0°, 6°), Júpiter'),'Toque sin explicación');
 const previous=JSON.stringify(positions());get('show-terms').click();assert(!svg().querySelector('[data-term]'),'No oculta');assert(JSON.stringify(positions())===previous,'Cambia planetas');get('show-terms').click();assert(svg().querySelectorAll('[data-term]').length===60,'No recupera');
 assert([...doc.querySelectorAll('.dignity-score')].every(r=>r.hidden),'Puntuación visible por defecto');get('show-dignity-score').click();assert([...doc.querySelectorAll('.dignity-score')].every(r=>!r.hidden),'No muestra puntuación');get('show-dignity-score').click();
 const labels=[...svg().querySelectorAll('[data-term] [data-label]')].map(g=>g.getBoundingClientRect());
 for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){const a=labels[i],b=labels[j];assert(!(a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top),'Etiquetas de términos superpuestas');}
});
await check('PNG válido de 3300 × 3300 y modo impresión sin fuentes externas',async()=>{change('wheel-mode','print');const source=new XMLSerializer().serializeToString(svg());assert(svg().querySelectorAll('[data-term]').length===60,'Faltan términos en SVG exportado');assert(!source.includes('#fffaf0'),'Color de pantalla en impresión');assert(!source.includes('<text'),'Texto depende de fuentes');const blob=await pngBlob(source);assert(blob.type==='image/png','No es PNG');const bitmap=await createImageBitmap(blob);assert(bitmap.width===3300&&bitmap.height===3300,'Resolución incorrecta');bitmap.close();change('wheel-mode','color');});
await check('Placidus polar: error, sin carta parcial, recuperación al elegir signos enteros',async()=>{
 fill('date','2024-06-21');fill('time','12:00:00');fill('latitude','69.6492');fill('longitude','18.9553');fill('timezone','Etc/UTC');get('chart-form').requestSubmit();await until(()=>!get('results').hidden);
 change('house-system','placidus');await until(()=>!get('error').hidden);assert(get('error').textContent.includes('HOUSE_CALCULATION_FAILED'),'Error no identificado');assert(get('results').hidden,'Presenta resultados parciales');change('house-system','whole_sign');await until(()=>!get('results').hidden);assert(svg().dataset.houseSystem==='whole_sign','No recupera');
});
document.querySelector('#summary').textContent=`${passed} pruebas aprobadas; ${failed} fallidas.`;
document.querySelector('#summary').dataset.passed=String(passed);document.querySelector('#summary').dataset.failed=String(failed);
