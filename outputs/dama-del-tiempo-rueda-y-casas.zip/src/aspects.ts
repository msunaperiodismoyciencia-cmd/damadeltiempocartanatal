// Reglas geométricas de aspectos; no calcula posiciones astronómicas. AGPL-3.0-only.
export const traditionalPlanets = ['Sol','Luna','Mercurio','Venus','Marte','Júpiter','Saturno'];
export const aspectDefinitions = [
 {name:'Conjunción', angle:0}, {name:'Sextil',angle:60}, {name:'Cuadratura',angle:90},
 {name:'Trígono',angle:120}, {name:'Oposición',angle:180}
] as const;
export type Aspect = {from:string;to:string;name:string;angle:number;separation:number;orb:number;limit:number};
export type Orbs = Record<string,number|undefined>;
export function pairKey(a:string,b:string){return [a,b].sort().join('|');}
export function separation(a:number,b:number){return Math.abs(((a-b)%360+540)%360-180);}
export function calculateAspects(bodies:ReadonlyArray<{name:string;longitude:number}>,orbs:Orbs):Aspect[]{
 const planets=bodies.filter(b=>traditionalPlanets.includes(b.name)); const result:Aspect[]=[];
 for(let i=0;i<planets.length;i++)for(let j=i+1;j<planets.length;j++){
  const a=planets[i],b=planets[j],limit=orbs[pairKey(a.name,b.name)];
  if(limit===undefined)continue;
  if(!Number.isFinite(limit)||limit<0||limit>30)throw Error('El orbe debe estar entre 0° y 30°.');
  const distance=separation(a.longitude,b.longitude);
  // Si un orbe amplio admite más de un aspecto, se conserva el más próximo
  // a la exactitud (empate: menor ángulo). Convención visible en la interfaz.
  const candidate=[...aspectDefinitions].sort((x,y)=>Math.abs(distance-x.angle)-Math.abs(distance-y.angle)||x.angle-y.angle)[0];
  const orb=Math.abs(distance-candidate.angle);
  if(orb<=limit+1e-10)result.push({from:a.name,to:b.name,name:candidate.name,angle:candidate.angle,separation:distance,orb,limit});
 }
 return result;
}
