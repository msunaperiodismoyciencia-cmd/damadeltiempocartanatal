// Banco de pruebas real del navegador, sin dependencias adicionales.
import {pngBlob,renderWheel,defaultOptions,bodyGlyphs} from '/wheel.js';
const frame=document.querySelector('#app'),checks=document.querySelector('#checks');let passed=0,failed=0;
function assert(value,message){if(!value)throw Error(message);}
async function until(fn){const start=performance.now();while(!fn()){if(performance.now()-start>12000)throw Error('Tiempo agotado esperando la interfaz.');await new Promise(r=>setTimeout(r,30));}}
async function check(name,fn){try{await fn();passed++;const li=document.createElement('li');li.className='pass';li.textContent='OK · '+name;checks.append(li);}catch(e){failed++;const li=document.createElement('li');li.className='fail';li.textContent='FALLÓ · '+name+': '+e.message;checks.append(li);}}
await until(()=>frame.contentDocument?.querySelector('#calculate')&&!frame.contentDocument.querySelector('#calculate').disabled);
const doc=frame.contentDocument,get=id=>doc.getElementById(id);
const change=(id,value)=>{get(id).value=value;get(id).dispatchEvent(new Event('change',{bubbles:true}));};
const fill=(id,value)=>{get(id).value=value;get(id).dispatchEvent(new Event('input',{bubbles:true}));};
const svg=()=>get('wheel').querySelector('svg');
const positions=()=>[...svg().querySelectorAll('[data-planet]')].map(p=>[p.dataset.planet,p.dataset.longitude]);
get('sample').click();get('chart-form').requestSubmit();
await until(()=>svg()&&!get('results').hidden);
let original=JSON.stringify(positions());
await check('SVG válido, accesible, 360 marcas y nueve cuerpos',()=>{assert(!new DOMParser().parseFromString(svg().outerHTML,'image/svg+xml').querySelector('parsererror'),'XML inválido');assert(svg().querySelector('desc'),'Falta descripción');assert(svg().querySelectorAll('[data-degree]').length===360,'Marcas');assert(positions().length===9,'Cuerpos');});
for(const system of ['alcabitius','regiomontanus','placidus','whole_sign'])await check('Selector, tabla, rueda y exportación coinciden: '+system,async()=>{
 change('house-system',system);await until(()=>!get('results').hidden&&svg()?.dataset.houseSystem===system);
 assert(JSON.stringify(positions())===original,'Cambiaron planetas');
 const cusps=[...svg().querySelectorAll('[data-cusp]')],rows=[...get('cusps').rows];assert(cusps.length===12&&rows.length===12,'Doce cúspides');
 for(let i=0;i<12;i++)assert(Math.abs(Number(cusps[i].dataset.longitude)-parseFloat(rows[i].cells[4].textContent))<.000001,'Tabla/rueda distintos');
 const serialized=new XMLSerializer().serializeToString(svg()),parsed=new DOMParser().parseFromString(serialized,'image/svg+xml');assert(parsed.documentElement.getAttribute('data-house-system')===system,'SVG pierde sistema');
 if(system==='whole_sign'){assert(cusps.every(c=>Number(c.dataset.longitude)%30===0),'No empiezan a cero');assert(Number(svg().querySelector('[data-axis="ASC"]').dataset.longitude)!==Number(cusps[0].dataset.longitude),'ASC confundido con I');}
});
await check('Orbes independientes por pareja y controles de aspectos',async()=>{get('orb-inputs').querySelector('input[aria-label="Orbe Sol – Luna en grados"]').value='6';get('orb-inputs').querySelector('input').dispatchEvent(new Event('input',{bubbles:true}));assert(svg().querySelectorAll('[data-aspect]').length===1,'Falta sextil Sol–Luna');get('show-aspects').click();assert(!svg().querySelector('[data-aspect]'),'No oculta aspectos');get('show-aspects').click();});
await check('Orbe inválido impide una exportación obsoleta y se recupera al corregir',()=>{const input=get('orb-inputs').querySelector('input');input.value='-1';input.dispatchEvent(new Event('input',{bubbles:true}));assert(!svg(),'Conserva rueda obsoleta');assert(get('download-svg').disabled&&get('download-png').disabled,'Permite descargar');input.value='6';input.dispatchEvent(new Event('input',{bubbles:true}));assert(svg()&&!get('download-svg').disabled,'No recupera rueda');});
await check('Ocultar grados y cúspides conserva los ángulos reales',()=>{get('show-degrees').click();assert(!svg().querySelector('[data-label="10°22′"]'),'No oculta grado');get('show-degrees').click();get('show-cusps').click();assert(!svg().querySelector('[data-cusp]'),'No oculta cúspides');assert(svg().querySelectorAll('[data-axis]').length===4,'Ocultó ángulos');get('show-cusps').click();});
for(const mobile of [false,true])await check('Sin recortes ni desbordamiento: '+(mobile?'390 px':'1366 px'),async()=>{
 frame.classList.toggle('mobile',mobile);await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
 assert(doc.documentElement.scrollWidth<=frame.clientWidth,'Desbordamiento de página');const rect=svg().getBoundingClientRect();assert(Math.abs(rect.width-rect.height)<1,'No es cuadrada');
 const inverse=svg().getScreenCTM().inverse();
 for(const path of svg().querySelectorAll('path')){const b=path.getBBox(),matrix=inverse.multiply(path.getScreenCTM());for(const [x,y] of [[b.x,b.y],[b.x+b.width,b.y],[b.x,b.y+b.height],[b.x+b.width,b.y+b.height]]){const p=new DOMPoint(x,y).matrixTransform(matrix);assert(p.x>=0&&p.y>=0&&p.x<=1100&&p.y<=1100,'Glifo fuera del SVG');}}
 if(mobile){change('wheel-zoom','300');assert(get('wheel').clientWidth>get('wheel').parentElement.clientWidth*2.9,'Zoom no funciona');assert(doc.documentElement.scrollWidth<=frame.clientWidth,'Zoom desborda página');change('wheel-zoom','100');}
});
await check('PNG válido de 3300 × 3300 y modo impresión sin fuentes externas',async()=>{change('wheel-mode','print');const source=new XMLSerializer().serializeToString(svg());assert(!source.includes('#fffaf0'),'Color de pantalla en impresión');assert(!source.includes('<text'),'Texto depende de fuentes');const blob=await pngBlob(source);assert(blob.type==='image/png','No es PNG');const bitmap=await createImageBitmap(blob);assert(bitmap.width===3300&&bitmap.height===3300,'Resolución incorrecta');bitmap.close();change('wheel-mode','color');});
await check('Placidus polar: error, sin carta parcial, recuperación al elegir signos enteros',async()=>{
 fill('date','2024-06-21');fill('time','12:00:00');fill('latitude','69.6492');fill('longitude','18.9553');fill('timezone','Etc/UTC');get('chart-form').requestSubmit();await until(()=>!get('results').hidden);
 change('house-system','placidus');await until(()=>!get('error').hidden);assert(get('error').textContent.includes('HOUSE_CALCULATION_FAILED'),'Error no identificado');assert(get('results').hidden,'Presenta resultados parciales');change('house-system','whole_sign');await until(()=>!get('results').hidden);assert(svg().dataset.houseSystem==='whole_sign','No recupera');
});
document.querySelector('#summary').textContent=`${passed} pruebas aprobadas; ${failed} fallidas.`;
document.querySelector('#summary').dataset.passed=String(passed);document.querySelector('#summary').dataset.failed=String(failed);
