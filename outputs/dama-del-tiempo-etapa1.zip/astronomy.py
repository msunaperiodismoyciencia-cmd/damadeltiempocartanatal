"""Solo resultados del motor astronómico Swiss Ephemeris. AGPL-3.0-only."""
from pathlib import Path
import swisseph as swe

EPHE = Path(__file__).parent / 'ephe'
PLANETS = [(swe.SUN, 'Sol'), (swe.MOON, 'Luna'), (swe.MERCURY, 'Mercurio'),
           (swe.VENUS, 'Venus'), (swe.MARS, 'Marte'), (swe.JUPITER, 'Júpiter'),
           (swe.SATURN, 'Saturno')]


def calculate(utc, latitude, longitude, node='mean'):
    if not 1800 <= utc.year <= 2399:
        raise ValueError('Esta etapa admite fechas UTC entre 1800 y 2399, con calendario gregoriano.')
    if not -66 < latitude < 66 or not -180 <= longitude <= 180:
        raise ValueError('Ingresá longitud entre −180 y 180 y latitud entre −66 y 66. Las regiones polares quedan pendientes de validación.')
    if node not in ('mean', 'true'):
        raise ValueError('Seleccioná nodo medio o verdadero.')
    for name in ('sepl_18.se1', 'semo_18.se1'):
        if not (EPHE / name).is_file():
            raise ValueError('Faltan las efemérides oficiales. No se realizará un cálculo alternativo.')
    swe.set_ephe_path(str(EPHE))
    tt, ut1 = swe.utc_to_jd(utc.year, utc.month, utc.day, utc.hour, utc.minute,
                          utc.second + utc.microsecond / 1e6, swe.GREG_CAL)
    bodies = []
    for ident, name in PLANETS + [(swe.MEAN_NODE if node == 'mean' else swe.TRUE_NODE, 'Nodo Norte')]:
        values, flags = swe.calc(tt, ident, swe.FLG_SWIEPH | swe.FLG_SPEED)
        # Los nodos son puntos analíticos del propio motor; para los planetas
        # se rechaza expresamente cualquier fallback automático a Moshier.
        if ident in [p[0] for p in PLANETS] and not flags & swe.FLG_SWIEPH:
            raise ValueError('Swiss Ephemeris no utilizó los archivos previstos; cálculo cancelado.')
        bodies.append({'name': name, 'longitude': values[0], 'latitude': values[1],
                       'speed': values[3], 'flags': flags})
    try:
        cusps, angles = swe.houses_ex(ut1, latitude, longitude, b'B')
    except swe.Error:
        raise ValueError('No se pudo calcular Alcabitius para este lugar y fecha.')
    return {'bodies': bodies, 'cusps': list(cusps), 'ascendant': angles[0],
            'midheaven': angles[1], 'jd_tt': tt, 'jd_ut1': ut1,
            'engine': swe.version, 'node': node}
