"""Servidor exclusivamente local, sin persistencia de cartas. AGPL-3.0-only."""
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode
from urllib.request import urlopen, Request
import json
import math
import mimetypes
import io
import zipfile
import webbrowser
import argparse
from datetime import datetime, timezone
from time_conversion import local_to_utc
from astronomy import calculate
from rules import present

ROOT = Path(__file__).parent


def chart(data):
    try:
        lat, lon = float(data['latitude']), float(data['longitude'])
        threshold = float(data.get('station_threshold', .001))
        if not all(map(math.isfinite, (lat, lon, threshold))) or not 0 <= threshold <= .1:
            raise ValueError('Revisá las coordenadas y el umbral estacionario (0 a 0,1).')
        utc, timing = local_to_utc(data['date'], data['time'], data['timezone'], data.get('fold'))
        raw = calculate(utc, lat, lon, data.get('node', 'mean'))
        warnings = []
        if utc.year < 1970:
            warnings.append('Los datos horarios anteriores a 1970 pueden ser incompletos: verificá la hora legal histórica.')
        if utc > datetime.now(timezone.utc):
            warnings.append('Fecha futura: las reglas de horario legal y los parámetros temporales pueden cambiar.')
        return {'astronomy': raw, 'results': present(raw, threshold), 'time': timing,
                'location': {'latitude': lat, 'longitude': lon},
                'warnings': warnings}
    except (KeyError, TypeError):
        raise ValueError('Faltan datos o su formato no es válido.')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Ni nombres, ni fechas, ni búsquedas en registros.

    def send(self, status, data, content_type='application/json; charset=utf-8'):
        if not isinstance(data, bytes):
            data = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(data)

    def valid_host(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}')

    def do_GET(self):
        if not self.valid_host():
            return self.send(403, {'error': 'Acceso permitido solamente desde localhost.'})
        url = urlparse(self.path)
        if url.path == '/api/places':
            name = parse_qs(url.query).get('q', [''])[0].strip()
            if not 2 <= len(name) <= 120:
                return self.send(400, {'error': 'Ingresá entre 2 y 120 caracteres para buscar.'})
            try:
                endpoint = 'https://geocoding-api.open-meteo.com/v1/search?' + urlencode({'name': name, 'count': 8, 'language': 'es'})
                with urlopen(Request(endpoint, headers={'User-Agent': 'DamaDelTiempo-local/0.1'}), timeout=12) as response:
                    data = json.load(response)
                return self.send(200, {'results': data.get('results', [])})
            except Exception:
                return self.send(503, {'error': 'No se pudo consultar localidades. Podés ingresar coordenadas y zona IANA manualmente.'})
        if url.path == '/source.zip':
            stream = io.BytesIO()
            with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
                for path in ROOT.rglob('*'):
                    if path.is_file() and not any(p in ('.venv', 'node_modules', '__pycache__', '.git') for p in path.relative_to(ROOT).parts):
                        archive.write(path, path.relative_to(ROOT))
            return self.send(200, stream.getvalue(), 'application/zip')
        allowed = {'/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/favicon.svg': 'favicon.svg'}
        if url.path in allowed:
            file = ROOT / 'web' / allowed[url.path]
            if file.is_file():
                mime = {'html': 'text/html', 'js': 'text/javascript', 'css': 'text/css', 'svg': 'image/svg+xml'}[file.suffix[1:]]
                return self.send(200, file.read_bytes(), mime + '; charset=utf-8')
        if url.path == '/license':
            return self.send(200, (ROOT / 'LICENSE').read_bytes(), 'text/plain; charset=utf-8')
        self.send(404, {'error': 'Página no encontrada.'})

    def do_POST(self):
        origin = self.headers.get('Origin')
        if not self.valid_host() or (origin and origin not in (f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}')):
            return self.send(403, {'error': 'Origen no permitido.'})
        if self.path != '/api/chart':
            return self.send(404, {'error': 'Ruta no encontrada.'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 10000:
                raise ValueError('Tamaño de solicitud inválido.')
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('Se requiere JSON.')
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise ValueError('Formato de solicitud inválido.')
            return self.send(200, chart(data))
        except (ValueError, OverflowError) as exc:
            return self.send(400, {'error': str(exc)})
        except Exception:
            return self.send(500, {'error': 'El motor no pudo completar el cálculo. Revisá la instalación.'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Dama del Tiempo: uso local')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--open', action='store_true')
    args = parser.parse_args()
    server = HTTPServer(('127.0.0.1', args.port), Handler)
    url = f'http://127.0.0.1:{args.port}'
    print(f'Dama del Tiempo disponible en {url}', flush=True)
    if args.open:
        webbrowser.open(url)
    server.serve_forever()
