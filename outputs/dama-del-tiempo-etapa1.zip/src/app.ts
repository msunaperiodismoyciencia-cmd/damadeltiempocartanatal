// Dama del Tiempo · AGPL-3.0-only. Presentación; no calcula posiciones.
export {};
type Body = {name:string; position:string; alcabitius:number; whole_sign:number; speed:number; motion:string};
type Result = {results:{bodies:Body[]; angles:{name:string;position:string}[];cusps:{house:number;position:string;whole_sign:string}[];station_threshold:number}; time:{utc:string;local:string;zone:string;offset_seconds:number;dst_seconds:number;tzdata:string}; astronomy:{engine:string;jd_tt:number;jd_ut1:number;node:string};warnings:string[]};
type Place = {name:string;admin1?:string;country?:string;latitude:number;longitude:number;timezone?:string};
const el = <T extends HTMLElement = HTMLElement>(id:string) => document.getElementById(id) as T;
const value = (id:string) => el<HTMLInputElement>(id).value;
const set = (id:string,v:string) => { el<HTMLInputElement>(id).value=v; };
const form=el<HTMLFormElement>('chart-form');
let revision=0;
let searchVersion=0;
function invalidate(){revision++;el('results').hidden=true;el('empty').hidden=false;el('error').hidden=true;el('status').textContent='Datos modificados. Calculá para obtener resultados actualizados.';}
form.addEventListener('input',invalidate);
el('place').addEventListener('input',()=>{searchVersion++;el('place-results').replaceChildren();el('place-status').textContent='';set('latitude','');set('longitude','');set('timezone','');});
async function api(url:string,init?:RequestInit){const response=await fetch(url,init);const data=await response.json();if(!response.ok)throw Error(data.error||'No se pudo completar la solicitud.');return data;}
el('search').addEventListener('click',async()=>{
 const version=++searchVersion;const button=el<HTMLButtonElement>('search');button.disabled=true;el('place-results').replaceChildren();el('place-status').textContent='Buscando localidades…';
 try{const data=await api('/api/places?q='+encodeURIComponent(value('place')));if(version!==searchVersion)return;
  el('place-status').textContent=data.results.length?'Elegí la localidad correcta.':'No se encontraron localidades. Probá con ciudad y país o ingresá los datos manualmente.';
  for(const place of data.results as Place[]){if(!place.timezone)continue;const b=document.createElement('button');b.type='button';const label=[place.name,place.admin1,place.country].filter(Boolean).join(', ');b.textContent=label;b.addEventListener('click',()=>{set('place',label);set('latitude',String(place.latitude));set('longitude',String(place.longitude));set('timezone',place.timezone!);el('place-results').replaceChildren();el('place-status').textContent='Localidad seleccionada. Coordenadas del centro urbano; podés ajustarlas.';invalidate();});el('place-results').append(b);}
 }catch(error){if(version===searchVersion)el('place-status').textContent=(error as Error).message;}finally{button.disabled=false;}
});
el('sample').addEventListener('click',()=>{set('name','Ejemplo · Greenwich');set('date','2000-01-01');set('time','12:00:00');set('place','Greenwich, Reino Unido · punto de referencia');set('latitude','51.4779');set('longitude','0');set('timezone','Etc/UTC');set('fold','');set('node','mean');set('threshold','0.001');el('place-results').replaceChildren();el('place-status').textContent='Ejemplo de comprobación: 1 de enero de 2000, 12:00 UTC.';invalidate();});
function row(target:string,values:(string|number)[],retro=false){const tr=document.createElement('tr');values.forEach((v,i)=>{const cell=document.createElement('td');cell.textContent=String(v);if(retro&&i===5)cell.className='retro';tr.append(cell);});el(target).append(tr);}
function render(data:Result,name:string){el('bodies').replaceChildren();el('cusps').replaceChildren();el('angles').replaceChildren();el('chart-name').textContent=name.trim()||'Carta sin nombre';
 el('time-summary').textContent=`Hora local: ${data.time.local.replace('T',' ')}\nUTC: ${data.time.utc.replace('T',' ')} · ${data.time.zone}`;
 el('warning').textContent=data.warnings.join(' ');el('warning').hidden=!data.warnings.length;
 for(const angle of data.results.angles){const box=document.createElement('div');box.className='angle';const label=document.createElement('small');label.textContent=angle.name;const p=document.createElement('strong');p.textContent=angle.position;box.append(label,p);el('angles').append(box);}
 for(const b of data.results.bodies)row('bodies',[b.name,b.position,b.alcabitius,b.whole_sign,b.speed.toFixed(6),b.motion],b.motion==='Retrógrado');
 for(const c of data.results.cusps)row('cusps',[c.house,c.position,c.whole_sign]);
 el('technical').textContent=`Swiss Ephemeris ${data.astronomy.engine}\nEfemérides: sepl_18.se1 / semo_18.se1\nCalendario gregoriano · posiciones aparentes tropicales y geocéntricas\nDía juliano TT: ${data.astronomy.jd_tt}\nDía juliano UT1: ${data.astronomy.jd_ut1}\nIANA tzdata: ${data.time.tzdata}\nDesfase respecto de UTC: ${data.time.offset_seconds} segundos\nComponente de horario de verano: ${data.time.dst_seconds} segundos\nNodo: ${data.astronomy.node==='mean'?'medio':'verdadero'}\nUmbral estacionario: ${data.results.station_threshold} °/día\nNodo Sur: opuesto al Nodo Norte. Casas por longitud eclíptica.\nNo se aplican interpretaciones ni regla de los 5°.`;
 el('empty').hidden=true;el('results').hidden=false;
}
form.addEventListener('submit',async(event)=>{event.preventDefault();const current=revision;const name=value('name');const button=el<HTMLButtonElement>('calculate');button.disabled=true;el('error').hidden=true;el('results').hidden=true;el('status').textContent='Calculando con Swiss Ephemeris…';
 try{const result=await api('/api/chart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({date:value('date'),time:value('time'),latitude:Number(value('latitude')),longitude:Number(value('longitude')),timezone:value('timezone').trim(),fold:value('fold')===''?null:Number(value('fold')),node:value('node'),station_threshold:Number(value('threshold'))})});if(current!==revision)return;render(result,name);el('status').textContent='Cálculo completado.';
 }catch(error){if(current===revision){el('error').textContent=(error as Error).message;el('error').hidden=false;el('empty').hidden=false;el('status').textContent='';}}finally{button.disabled=false;}
});
