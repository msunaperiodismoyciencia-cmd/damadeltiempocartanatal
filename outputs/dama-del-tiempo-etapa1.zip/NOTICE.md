# Avisos de terceros

Este proyecto utiliza Swiss Ephemeris bajo la opción AGPL. Su aviso original íntegro está en `licenses/Swiss-Ephemeris.txt`; los avisos del código C y de pyswisseph se conservan también en la distribución fuente original de `vendor-sources/pyswisseph-2.10.3.2.tar.gz`.

pyswisseph: copyright de Stanislas Marquis y colaboradores, AGPLv3. Ver el aviso original incluido en `licenses/pyswisseph.txt`.

TypeScript: Copyright Microsoft Corporation, Apache-2.0. Ver `licenses/TypeScript.txt` y `licenses/TypeScript-third-party.txt`.

tzdata: copyright Python Software Foundation y colaboradores, Apache-2.0; datos IANA de dominio público. Ver los avisos originales en `licenses/`.

Localidades: [Open-Meteo](https://open-meteo.com/) y [GeoNames](https://www.geonames.org/), utilizados mediante el servicio opcional de geocodificación. Datos bajo [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) según el proveedor. Se seleccionan nombre, región, país, coordenadas y zona sin modificar los valores recibidos; el usuario puede corregirlos manualmente. No se incluye una base de localidades redistribuida.

Ninguno de estos proveedores avala Dama del Tiempo. La aplicación se entrega sin garantía, conforme a las licencias respectivas.
