# Validación de la etapa 1

Fecha: 19 de septiembre de 2026. Entorno: Windows, Python 3.11, pyswisseph 2.10.3.2 (motor 2.10.03), tzdata 2026.2 y TypeScript 5.9.3.

## Resultado automatizado

**31 pruebas aprobadas**, ejecutadas con:

```text
.venv\Scripts\python.exe -m unittest discover -s tests -v
Ran 31 tests
OK
```

Compilación TypeScript (`npm run build`) y comprobación de tipos (`npm run check`) completadas sin errores.

Las pruebas cubren:

- Longitud y velocidad de los siete planetas y nodo medio, en dos fechas/lugares.
- Ascendente, MC y doce cúspides Alcabitius en ambos hemisferios.
- Banderas del motor: se comprueba que utiliza los archivos Swiss y se rechaza la sustitución automática por Moshier.
- Error explícito ante efemérides ausentes, coordenadas o fechas fuera de alcance.
- Saturno retrógrado, Mercurio directo, criterio estacionario y nodo verdadero/Sur.
- Casas por signos enteros, límites de signos y vuelta de 360°; casas por intervalos de cúspides.
- Redondeo a minutos y acarreo al siguiente signo.
- UTC equivalente a hora local, horario de verano argentino de 2008 y ausencia en 2010, desplazamiento histórico con segundos, zona de media hora.
- Hora inexistente y hora repetida en Nueva York, exigiendo elección en esta última.
- Cambios de día, mes, año y 29 de febrero.
- Solicitud HTTP completa, mensajes de error, aislamiento de archivos y rechazo de solicitudes desde otro origen.

## Referencia astronómica

Se ejecutó el binario oficial `swetest64.exe` del repositorio de Swiss Ephemeris con los mismos archivos `sepl_18.se1` y `semo_18.se1`, modo tropical/geocéntrico, opción UTC, velocidad y casas `B` (Alcabitius). La salida quedó congelada en `tests/swetest-reference.json`, con comandos, entradas y huella del ejecutable.

Se comparan longitudes, velocidades, ángulos y cúspides con tolerancia absoluta de **0,000001°** (velocidades en °/día). Los valores de referencia no se regeneran durante los tests. Los dos casos son Greenwich, 1/1/2000, 12:00 UTC, y Buenos Aires, 15/6/1987, 15:30 UTC.

Esto verifica la integración contra una herramienta oficial independiente del código de esta aplicación; **no** es una comparación con otro modelo astronómico ni prueba exhaustivamente todas las fechas y latitudes. La concordancia al minuto con el programa de la usuaria sigue pendiente.

## Comprobación en navegador

- Formulario vacío y ejemplo de Greenwich: cálculo completo y nueve filas visibles (siete planetas y dos nodos).
- Búsqueda real de Buenos Aires: lista de coincidencias, selección de Argentina, coordenadas y zona IANA automáticas, cálculo exitoso.
- Cambio de datos: se oculta el resultado anterior hasta recalcular.
- Hora local repetida: el mensaje solicita primera o segunda ocurrencia.
- Comprobación de escritorio a 1366 px y teléfono a 390 px. Se corrigió un desbordamiento provocado por el ancho mínimo de la tabla. En 390 px, el documento ocupa 375 px más la barra de desplazamiento y no desborda; las tablas se desplazan horizontalmente en su propio contenedor.

La comprobación móvil usa un navegador con ancho simulado; no se probó en un teléfono físico ni en todos los navegadores. Las capturas del entorno se mostraron escaladas, por lo que se complementó la revisión visual con medidas del documento y lectura de controles y resultados.

## Validación de la astróloga pendiente

Seguí los dos ejemplos y la configuración de comparación en README.md. Confirmá las posiciones, Ascendente, MC y cúspides, y definí:

1. Nodo medio o verdadero como opción predeterminada.
2. Criterio y umbral de estacionariedad.
3. Pertenencia a casas por longitud eclíptica y eventual regla de los 5°.

No se avanzó a rueda, aspectos, exportaciones ni publicación. La etapa siguiente comienza después de esta validación.
